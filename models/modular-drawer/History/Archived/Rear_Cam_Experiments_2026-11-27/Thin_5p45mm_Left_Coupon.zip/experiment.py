import FreeCAD as A,Part,sys,json
from pathlib import Path
V=A.Vector
r=Part.read(sys.argv[1]).Solids
def b(x,y,z,u,v,w):return Part.makeBox(u-x,v-y,w-z,V(x,y,z))
def m(s,x=0,y=0,z=0):return s.translated(V(x,y,z))
def c(a,b):
 if not a.BoundBox.intersect(b.BoundBox):return 0.
 return a.common(b).Volume
def one(s):
 s=s.removeSplitter();assert s.isValid() and len(s.Solids)==1;return s.Solids[0]
def mir(s):return s.mirror(V(97.65,0,0),V(1,0,0))
shift=4.7; yc=237+shift; zc=92.; xc=37.2
def rot(s,a):
 t=s.copy();t.rotate(V(xc,yc,zc),V(0,1,0),a);return t
rod=m(r[8],y=shift,z=87)
# Shorten original wheel axially; radius and eccentric faces survive. Cover face is rear-facing.
cam=one(m(r[12],y=shift,z=87).common(b(30,239.5,85,45,244.95,99)))
# Drive slot is traversing the intact outer face, not the original buried front face.
slot=b(xc-.58,244.4,zc-2.45,xc+.58,245.04,zc+2.45)
cam=one(cam.cut(slot))
side=r[0]
# Fill only the old slotted end + stop pocket in original plate envelope.
fill=b(25.3,238.8,89.1,28.43,245.0,100.0)
rear=one(r[3].fuse([fill,mir(fill)]))
# The old flared lip extends slightly beyond nominal X/Y; remove it in the changed corner only.
rear=one(rear.cut([b(24.9,244.45,89.1,25.3,245.1,95), b(25.29,245,89.1,28.43,245.1,95),mir(b(24.9,244.45,89.1,25.3,245.1,95)),mir(b(25.29,245,89.1,28.43,245.1,95))]))
seat=Part.makeCylinder(4.28,5.68,V(xc,239.42,zc),V(0,1,0))
bore=Part.makeCylinder(2.38,8.40,V(25.24,yc,zc),V(1,0,0))
rear=one(rear.cut([seat,bore,mir(seat),mir(bore)]))
print('static',[(key,round(c(a,b),6)) for key,a,b in [('side/rod',side,rod),('side/rear',side,rear),('rear/rod',rear,rod),('rear/cam',rear,cam),('rod/cam',rod,cam),('drawer/rear',r[14],rear)]],flush=True)
for a in [-90,-85,-80,-75,-70,-60,-50,-40,-30,-20,-10,0,5,10,15,20]:
 t=rot(cam,a)
 print('turn',a,round(c(rod,t),6),round(c(rear,t),6),'axial pull',round(c(m(rod,x=-.3),t),6),round(c(m(rod,x=-.6),t),6),flush=True)
t=rot(cam,-80)
for x in [0,.1,.25,.5,.75,1,1.5,2,2.5,3,3.5,4,5,6,8,10,12,15]:
 print('open draw',x,round(c(m(rod,x=-x),t),6),round(c(m(rod,x=-x),rear),6),flush=True)
for y in [0,.1,.3,.5,1,2,3,4,5,6,8,10,12]:
 print('insert rod',y,round(c(m(rod,y=y),side),6),flush=True)
for y in [0, .5,1,2,4,7]:
 print('insert rotor only',y,round(c(m(t,y=y),rear),6),flush=True)
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
coupon=[one(side.common(b(15,230,84,25.3,245.1,100.1))),one(rear.common(b(25.3,238.5,84,44,245.1,100))),rod,cam]
Part.export if False else None
Part.makeCompound(coupon).exportStep(str(out/'Rear_Upper_Thin_Cam_Experiment.step'))
from step_units import ensure_mm
f=out/'Rear_Upper_Thin_Cam_Experiment.step'
ensure_mm(f,Part.makeCompound(coupon))
q=Part.read(str(f));assert q.isValid() and len(q.Solids)==4
assert max(c(a,b) for i,a in enumerate(q.Solids) for b in q.Solids[i+1:])<.001
left=[side,rear,rod,cam]
def checkmove(s,gaps,along='x'):
 return [[v,round(c(s,m(rod,**{along:v})),7)] for v in gaps]
locked=checkmove(rot(cam,10),[0,-.025,-.05,-.075,-.1,-.125,-.15,-.175,-.2,-.225,-.25,-.3,-.6])
axial=[[d,round(c(rod,m(rot(cam,10),y=d)),7)]for d in [.05,.1,.2,.3,.5,1,2,3,4,5,6]]
draw=[]
base=r[:15]
full=base[:3]+[rear]+base[4:]+[rod,mir(rod),cam,mir(cam)]
for d in [0,-.1,-.3,-.6,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-12,-16,-22,-30,-45,-60,-85,-100,-110.5]:
 v=max(c(m(r[14],y=d),p) for p in full if p is not r[14])
 assert v<.001,(d,v)
 draw.append([d,round(v,7)])
assert max(c(a,b) for i,a in enumerate(full) for b in full[i+1:])<.001
x0,x1,y0,y1,z0,z1=[25.29,170.01,238.79,245.1,87.70,100.01]
zone=[b(x0,y0,z0,43,y1,z1),b(152,y0,z0,x1,y1,z1)]
assert rear.cut(r[3]).cut(zone).Volume<.001
assert r[3].cut(rear).cut(zone).Volume<.001
X=type(q.Solids[0].Faces[0].Surface).__name__
metrics=dict(cad_sample_count=len(draw),travel_mm=110.5,nominal_clearance_mm=.8,cam_diameter_mm=8.2,cam_thickness_mm=5.45,baseline_cam_thickness_mm=11.2,rear_wall_nominal_mm=6.2,front_floor_mm=.62,recess_mm=.05,slot_depth_mm=.55,rod_shift_y_mm=shift,locked_tolerance_samples=locked,cam_rear_pull_samples=axial,checked_lock_angle_deg=10,drawer_samples=draw,source_length_units='mm')
(out/'fit.json').write_text(json.dumps(metrics,indent=2)+'\n')
print('FIT',json.dumps(metrics),flush=True)
