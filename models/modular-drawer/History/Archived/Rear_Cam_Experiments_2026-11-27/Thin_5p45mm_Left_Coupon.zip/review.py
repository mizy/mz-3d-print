from pathlib import Path
import sys,json,html,hashlib
from report_geometry import Part,bbox,views,meshes,size
here=Path(__file__).parent
out=here/'out'
f=out/'Rear_Upper_Thin_Cam_Experiment.step'
root=Path(sys.argv[1])
template=(root/'rear-key-template.html').read_text()
runtime=(root/'mz-viewer.runtime.js').read_text().replace('后板背插键 · 关合总成','薄偏心轮 · 后上角局部总成')
q=Part.read(str(f))
assert q.isValid() and len(q.Solids)==4
fit=json.loads((out/'fit.json').read_text())
items=[('side','① 原侧板裁片'),('rear','② 后板裁片 · 浅轮座'),('rod','③ 拉杆 · 沿深度后移'),('cam','④ 薄偏心轮 · 后侧一字槽')]
def part(s,name):
 b=bbox(s); return dict(name=name,extent=size(b),nSolids=len(s.Solids),**meshes(s,b,.05))
parts={'assembly':part(q,f.name)}
for packet,k in zip(parts['assembly']['meshes'],['side','rear','hardware','hardware']):packet['kind']=k
panels=[];draw=[]
for (k,title),s in zip(items,q.Solids):
 p=parts[k]=part(s,title)
 p['meshes'][0]['kind']=k if k in ('side','rear') else 'hardware'
 panels.append(dict(id=k,mesh=k,title=title))
 vv=views(s,['rear_end','top','side'],include_tangent=True)
 fs=[]
 for v in vv:
  w,h=v['extent'];x,y=(36-w)/2,(28-h)/2
  def pts(e):return ' '.join(f'{a+x:.4f},{h-b+y:.4f}' for a,b in e)
  ls=''.join(f'<polyline fill="none" stroke="{c}" stroke-width=".16" {dash} points="{pts(e)}"/>' for layer,c,dash in zip(v['layers'],['#243b4b','#91a7ab'],['','stroke-dasharray=".65 .55"']) for e in layer)
  for a,b,r in v['visible_full_circles']: ls+=f'<circle cx="{a+x}" cy="{h-b+y}" r="{r}" stroke="#243b4b" stroke-width=".16" fill="none"/>'
  fs.append(f'<figure class="view"><figcaption>{v["title"]}<small>{v["axes"]} ｜ {w:g} × {h:g} mm</small></figcaption><svg viewBox="0 0 36 28" aria-label="{v["title"]}">{ls}</svg></figure>')
 draw.append(f'<div class="sheet"><h3>{title}</h3><div class="ortho">{"".join(fs)}</div></div>')
intro=template[:template.index('<header>')].replace('<title>模块化抽屉 · 后板插键与关合评审</title>','<title>薄偏心轮 · 后上角 CAD 小样</title>')
intro=intro[:intro.rfind('</head>')]+ '<title>薄偏心轮 · 后上角 CAD 小样</title></head><body>'
viewer=template[template.index('<section id="review3d"'):template.index('<section id="joints"')]
viewer=viewer.replace('关闭总成和部件切换','后上角 · 总成与单件').replace('亮蓝绿：侧板　蓝：前梁　深蓝：后板　橙：插键、锁件与拨片','蓝绿：侧板　深蓝：后板　橙：拉杆与薄偏心轮')
intro+='<main class="wrap"><div class="hero"><p class="kicker">独立试验 · 不替换项目现版</p><h1>后上角薄偏心轮</h1><p class="lead">只改后板上方的锁座和对应锁件。原侧板、前梁、抽屉及下锁不改。</p></div>'
metrics=f'''<section><h2>CAD 检查结果</h2><div class="sheet"><p>沿用 Ø8.2 mm 偏心工作轮廓，轴向厚度由 11.2 mm 变为 5.45 mm。轮端面低于后背 0.05 mm，从背面用一字槽操作。后板名义厚度 6.20 mm，浅轮座在非拉杆交叉处剩约 0.62 mm 底材；不是建议的量产余量。</p><p>以偏心轮原总成姿态为 0°，在 −80° 检查拉杆装拆，在 −90° 到 +10° 的采样角度检查转动；锁紧端 +10° 有拉杆防脱挡面。防脱不等于锁紧预载，也不能用交叠体积换算紧固力。</p><p>抽屉按 {fit['cad_sample_count']} 个姿态从关到底检查到拉出 {fit['travel_mm']} mm，无 CAD 干涉；关到底的原名义间隙 0.8 mm 不变。未切片，未试打、测扭矩或强度。</p></div><p class="note">先用真实耗材验证背面一字槽和轮座是否耐拧、锁紧后是否晃、能否顺利退出。不要直接替换双 T 正式版。</p></section>'''
data=json.dumps(dict(parts=parts,panels=panels),ensure_ascii=False,separators=(',',':')).replace('<','\u003c')
body=metrics+viewer+f'<section><h2>按实际 STEP 投影的三视图</h2><p>统一比例，单位 mm。实线：可见；虚线：隐藏。</p>{"".join(draw)}</section><section><h2>文件</h2><a href="{f.name}" download>4 实体 STEP 小样</a> · <a href="fit.json">CAD 样点数据</a><p class="sheet-note">STEP SHA-256: {hashlib.sha256(f.read_bytes()).hexdigest()}</p></section></main>'
(out/'index.html').write_text(intro+body+f'<script type="application/json" id="cad-data">{data}</script><script>{runtime}</script></body></html>')
print('HTML orthographic check passed',len(draw))
