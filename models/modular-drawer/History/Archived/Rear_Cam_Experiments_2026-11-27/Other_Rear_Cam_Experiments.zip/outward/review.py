import sys,json,base64,hashlib
from pathlib import Path
from report_geometry import Part,bbox,views,meshes,size
here=Path(__file__).parent; out=here/'out'; root=Path(sys.argv[1])
runtime=(root/'mz-viewer.runtime.js').read_text().replace('后板背插键 · 关合总成','后板局部加厚 · 偏心轮对照')
base=(root/'rear-key-template.html').read_text()
intro=base[:base.index('<header>')].replace('<title>模块化抽屉 · 后板插键与关合评审</title>','<title>后板局部加厚 · 偏心轮对照</title>')
viewer=base[base.index('<section id="review3d"'):base.index('<section id="joints"')]
viewer=viewer.replace('关闭总成和部件切换','完整关合总成与局部小样').replace('亮蓝绿：侧板　蓝：前梁　深蓝：后板　橙：插键、锁件与拨片','亮蓝绿：侧板　蓝：前梁　深蓝：后板　橙：偏心轮、拉杆与拨片')
full=out/'Rear_Thickened_Cam_Assembly.step'; coupon=out/'Rear_Thickened_Cam_Coupon.step'
q=Part.read(str(full)); p=Part.read(str(coupon))
assert len(q.Solids)==19 and len(p.Solids)==4 and q.isValid() and p.isValid()
def part(s,name,d=.065):
 b=bbox(s);return dict(name=name,extent=size(b),nSolids=len(s.Solids),**meshes(s,b,d))
parts={'assembly':part(q,'完整关合总成',.12),'corner':part(p,'左后上角小样')}
for m,k in zip(parts['corner']['meshes'],['side','rear','hardware','hardware']):m['kind']=k
panels=[dict(id='corner',mesh='corner',title='左后上角小样')]
draw=[]
items=[('side','① 原侧板裁片','沿用原侧板狭长槽，不打新孔。'),('rear','② 后板裁片','从外侧一孔装轮、拧轮；侧孔只供拉杆，不是第二个操作孔。'),('rod','③ 偏置拉杆','固定端仍套原侧板槽；只将锁紧端沿深度向后移 3.2 mm。'),('cam','④ 全厚偏心轮','保留 Ø8.2 × 11.2 mm 工作轮廓；背面增一字槽。')]
for (k,title,note),s in zip(items,p.Solids):
 parts[k]=part(s,title)
 if k in ('side','rear'):parts[k]['meshes'][0]['kind']=k
 panels.append(dict(id=k,mesh=k,title=title))
 fs=[]
 for v in views(s,['rear_end','top','side'],include_tangent=True):
  w,h=v['extent'];x,y=(38-w)/2,(28-h)/2
  def xy(a,b):return (x+a,y+h-b)
  def pts(e):return ' '.join(f'{sx:.4f},{sy:.4f}' for a,b in e for sx,sy in [xy(a,b)])
  ls=''.join(f'<polyline fill="none" stroke="{c}" stroke-width=".16" {dash} points="{pts(e)}"/>' for layer,c,dash in zip(v['layers'],['#243b4b','#91a7ab'],['','stroke-dasharray=".65 .55"']) for e in layer)
  for a,b,r in v['visible_full_circles']:
   cx,cy=xy(a,b);ls+=f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke="#243b4b" stroke-width=".16" fill="none"/>'
  if k=='rear' and v['key']=='rear_end':
   cx,cy=xy(v['brep_bounds'][1]-37.2,92-v['origin'][1]);ls+=f'<path d="M {cx:.3f} {cy:.3f} L {cx+6:.3f} {cy-5:.3f} H 35" fill="none" stroke="#bd651a" stroke-width=".16"/><text x="25" y="{cy-5.65:.3f}" fill="#a55014" font-size="1.24">Ø8.56 轮孔</text>'
  if k=='rear' and v['key']=='side':
   yy=y+h+1.3; xa=x+238.8-v['origin'][0];xb=x+251.45-v['origin'][0]
   ls+=f'<path d="M {xa:.3f} {yy-1:.3f} v 1.3 M {xb:.3f} {yy-1:.3f} v 1.3 M {xa:.3f} {yy:.3f} H {xb:.3f}" fill="none" stroke="#bd651a" stroke-width=".16"/><text x="{(xa+xb)/2:.3f}" y="{yy+1.45:.3f}" fill="#a55014" font-size="1.2" text-anchor="middle">局部厚 12.65</text>'
  fs.append(f'<figure class="view"><figcaption>{v["title"]}<small>{v["axes"]} ｜ {w:g} × {h:g} mm</small></figcaption><svg viewBox="0 0 38 31" aria-label="{v["title"]}">{ls}</svg></figure>')
 draw.append(f'<div class="sheet"><h3>{title}</h3><p>{note}</p><div class="ortho">{"".join(fs)}</div></div>')
fit=json.loads((out/'fit.json').read_text())
lead='''<main class="wrap"><div class="hero"><p class="kicker">独立试验 · 不替换项目现版</p><h1>后板局部加厚，恢复全厚偏心轮</h1><p class="lead">只向外加厚后板左、右上锁座。抽屉、侧板、前梁和下锁不变。</p></div>'''
depth=fit['overall_depth_mm']
metrics=f'''<section><h2>空间与装配</h2><div class="sheet"><p><strong>抽屉内部空间损失：0 mm。</strong>后板内侧不前移，闭合名义间隙仍为 0.8 mm，23 个行程姿态到拉出 110.5 mm 均未检出 CAD 干涉。</p><p><strong>代价是后背局部凸出 6.45 mm。</strong>两个上锁座厚度由 6.20 mm 增至 12.65 mm，其余后板没加厚。整组前后深度为 {depth:.2f} mm；如果柜内净深为 250 mm，名义余量 {250-depth:.2f} mm，未扣除墙面不平或操作空间。装入柜前从背面拧紧。</p><p>原轮 11.20 mm 厚，轮端面低于锁座外表面 0.25 mm。轮座底面名义余厚 1.00 mm（拉杆通道处除外）。局部改形拉杆保留两端咬合轮廓，锁紧端向后错开 3.20 mm。</p><p>已检查拉杆入槽、偏心轮插入、−90° 至 +10° 每 5° 转动、−80° 拆出和 +10° 防拔。防拔不代表预紧力通过。未切片，未试打或测扭矩。</p></div><p class="note">先打左后角 4 件小样。先把拉杆滑入原侧板槽，后板套入拉杆并将偏心轮从背面装入，同一孔操作；再试锁紧、摇晃与解锁。完整总成用于查看空间和干涉。</p></section>'''
def link(f,label,mime='application/octet-stream'):
 data=base64.b64encode(f.read_bytes()).decode()
 return f'<a href="data:{mime};base64,{data}" download="{f.name}">{label}</a>'
links=' · '.join([link(full,'19 实体总成 STEP'),link(coupon,'4 实体小样 STEP'),link(out/'fit.json','CAD 样点数据','application/json')])
body=metrics+viewer+f'<section><h2>按实际 STEP 投影的三视图</h2><p>统一比例，单位 mm。实线：可见；虚线：隐藏；橙色：关键尺寸或特征。</p>{"".join(draw)}</section><section><h2>下载</h2>{links}<p class="sheet-note">总成 STEP SHA-256: {hashlib.sha256(full.read_bytes()).hexdigest()}</p></section></main>'
data=json.dumps(dict(parts=parts,panels=panels),ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
f=out/'Drawer_Rear_Thickened_Cam_Review.html'
f.write_text(intro+lead+body+f'<script type="application/json" id="cad-data">{data}</script><script>{runtime}</script></body></html>')
print(f,f.stat().st_size)
