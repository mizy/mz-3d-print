import FreeCAD as A,Part,sys,json
from pathlib import Path
from step_units import ensure_mm
V=A.Vector
r=Part.read(sys.argv[1]).Solids
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def b(x,y,z,u,v,w):return Part.makeBox(u-x,v-y,w-z,V(x,y,z))
def m(s,x=0,y=0,z=0):return s.translated(V(x,y,z))
def c(a,b):
 if not a.BoundBox.intersect(b.BoundBox):return 0.
 return a.common(b).Volume
def one(s):
 s=s.removeSplitter()
 assert s.isValid() and len(s.Solids)==1,(s.isValid(),len(s.Solids))
 return s.Solids[0]
def mir(s):return s.mirror(V(97.65,0,0),V(1,0,0))
def ring(x,y,rad): return Part.Wire([Part.makeCircle(rad,V(x,y,92),V(1,0,0))])
def loft(x,y,u,v,rad):return Part.makeLoft([ring(x,y,rad),ring(u,v,rad)],True,True)
def cyl(x,y,rad,length):return Part.makeCylinder(rad,length,V(x,y,92),V(1,0,0))
side=r[0]; yc=244.9; xc=37.2; zc=92.; outer=251.45
def rot(s,a):
 t=s.copy();t.rotate(V(xc,yc,zc),V(0,1,0),a);return t
# Keep exact original side anchor, shaft neck and head; offset only the intervening shank.
base=m(r[8],y=4.7,z=87)
tip=m(r[8],y=7.9,z=87)
rod=one(base.common(b(21,238,88,25.88,247,96)).fuse([loft(25.54,241.7,31.90,yc,2.10),tip.common(b(31.50,240,88,39,249,96))]))
# Preserve full eccentric working diameter and axial thickness. Add rear access only.
cam=m(r[12],y=7.9,z=87)
cam=one(cam.cut(b(xc-.62,250.23,zc-2.7,xc+.62,251.26,zc+2.7)))
fill=b(25.3,238.8,89.1,28.43,245.0,100.0)
rear=one(r[3].fuse([fill,mir(fill)]))
rim=[b(24.9,244.45,89.1,25.3,245.1,95),b(25.29,245,89.1,28.43,245.1,95)]
rear=one(rear.cut(rim+[mir(s) for s in rim]))
# Only the upper corner grows outward. Bottom and inside shoulder stay unchanged.
# Taper the lower shoulder so the local thickening grows gradually from the panel.
pts=[V(25.3,244.7,82),V(25.3,outer,88.75),V(25.3,outer,100),V(25.3,244.7,100)]
pad=Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(18.7,0,0))
try: pad=pad.makeFillet(.8,[e for e in pad.Edges if e.BoundBox.XMin>43.99 and e.BoundBox.YMin>251.4 and e.Length>8])
except: pass
rear=one(rear.fuse([pad,mir(pad)]))
seat=Part.makeCylinder(4.28,outer-239.8+.1,V(xc,239.8,zc),V(0,1,0))
# Head passes through a straight side-entry bore, and the offset shank uses the lower half of a tapered slot.
entry=cyl(25.24,yc,2.40,8.57)
relief=loft(25.23,241.7,31.85,yc,2.4).fuse(cyl(25.24,241.7,2.40,.5))
# Constant head channel and lower offset channel joined via an envelope to avoid a pinch during insertion.
web=Part.makeBox(6.64,3.2,4.8,V(25.23,241.7,89.6))
relief=relief.fuse([web,cyl(25.24,241.7,2.42,1.22)])
rear=one(rear.cut([q for k in [seat,entry,relief] for q in [k,mir(k)]]))
print('static',[(n,round(c(a,b),7)) for n,a,b in [('side/rod',side,rod),('side/rear',side,rear),('rear/rod',rear,rod),('rear/cam',rear,cam),('rod/cam',rod,cam),('drawer/rear',r[14],rear)]],flush=True)
def sample(vals,fn):
 return [[t,*[round(x,7) for x in fn(t)]] for t in vals]
open_cam=rot(cam,-80)
turn=sample(list(range(-90,11,5)),lambda a:(c(rod,rot(cam,a)),c(rear,rot(cam,a))))
print('turn',turn,flush=True)
pull=sample([0,-.025,-.05,-.1,-.2,-.3,-.6,-1,-2,-3,-4,-5,-6,-8,-10,-13],lambda x:(c(m(rod,x=x),open_cam),c(m(rod,x=x),rear),c(m(rod,x=x),rot(cam,10))))
print('pull',pull,flush=True)
insert=sample([0,.2,.5,1,2,3,4,5,6,8,10,12],lambda y:(c(m(rod,y=y),side),c(m(open_cam,y=y),rear)))
print('insert',insert,flush=True)
base=r[:15]; full=base[:3]+[rear]+base[4:]+[rod,mir(rod),cam,mir(cam)]
static=max(c(a,b) for i,a in enumerate(full) for b in full[i+1:])
print('max-static',static,flush=True)
travel=[0,-.1,-.3,-.6,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-12,-16,-22,-30,-45,-60,-85,-100,-110.5]
drawer=sample(travel,lambda d:(max(c(m(r[14],y=d),p) for p in full if p is not r[14]),))
print('drawer',drawer,flush=True)
assert max(row[1] for row in drawer)<.001
assert max(max(row[1:]) for row in turn+insert)<.001
assert max(max(row[1:3]) for row in pull)<.001 and max(row[3] for row in pull)>.02
assert static<.001
zones=Part.makeCompound([b(25.10,238.79,81.9,44.01,251.50,100.01),b(151.29,238.79,81.9,170.2,251.50,100.01)])
assert rear.cut(r[3]).cut(zones).Volume<.001 and r[3].cut(rear).cut(zones).Volume<.001
def save(s,name,count):
 f=out/name;s.exportStep(str(f));ensure_mm(f,s)
 chk=Part.read(str(f));assert chk.isValid() and len(chk.Solids)==count
save(Part.makeCompound(full),'Rear_Thickened_Cam_Assembly.step',19)
save(Part.makeCompound([one(side.common(b(15,229,81,25.3,245.1,100.1))),one(rear.common(b(25.27,238.5,81,45,251.6,100.1))),rod,cam]),'Rear_Thickened_Cam_Coupon.step',4)
metrics=dict(cad_sample_count=len(drawer),travel_mm=110.5,nominal_clearance_mm=.8,local_thickness_mm=outer-238.8,cam_diameter_mm=8.2,cam_thickness_mm=11.2,rear_wall_nominal_mm=6.2,front_floor_mm=1.0,recess_mm=.25,slot_depth_mm=.97,rod_axis_offset_mm=3.2,outward_mm=outer-245,overall_depth_mm=outer-5,cabinet_nominal_depth_mm=250,volume_delta_mm3=rear.Volume-r[3].Volume,checked_lock_angle_deg=10,drawer_samples=drawer,turn_samples=turn,lock_samples=pull,assembly_samples=insert,max_static_overlap_mm3=static)
(out/'fit.json').write_text(json.dumps(metrics,indent=2)+'\n')
print('FIT',metrics,flush=True)
