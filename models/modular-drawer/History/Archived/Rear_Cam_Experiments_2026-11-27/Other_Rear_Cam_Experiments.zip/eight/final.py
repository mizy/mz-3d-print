import FreeCAD as A,Part,sys,json
from pathlib import Path
from step_units import ensure_mm
V=A.Vector
r=Part.read(sys.argv[1]).Solids
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def b(x,y,z,u,v,w):return Part.makeBox(u-x,v-y,w-z,V(x,y,z))
def m(s,x=0,y=0,z=0):return s.translated(V(x,y,z))
def c(a,b):
 if not a.BoundBox.intersect(b.BoundBox):return 0.
 return a.common(b).Volume
def one(s):
 s=s.removeSplitter()
 assert s.isValid() and len(s.Solids)==1,(s.isValid(),len(s.Solids))
 return s.Solids[0]
def mir(s):return s.mirror(V(97.65,0,0),V(1,0,0))
def ring(x,y,rad): return Part.Wire([Part.makeCircle(rad,V(x,y,92),V(1,0,0))])
def loft(x,y,u,v,rad):return Part.makeLoft([ring(x,y,rad),ring(u,v,rad)],True,True)
def cyl(x,y,rad,length):return Part.makeCylinder(rad,length,V(x,y,92),V(1,0,0))
side=r[0]; yc=240.75; xc=37.2; zc=92.; outer=245.0
def spin(s,x,y,z,a):
 t=s.copy();t.rotate(V(x,y,z),V(0,1,0),a);return t
def rot(s,a):return spin(s,xc,yc,zc,a)
def prism(x,width,yz):
 pts=[V(x,y,z) for y,z in yz]
 return Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(width,0,0))
def front_mirror(s):return s.mirror(V(0,125,0),V(0,1,0))
rod=m(r[8],y=3.75,z=87)
raw=r[12]
half=4.0
slot_depth=.85
def slot(y0,y1):return b(xc-.62,y0,5-2.7,xc+.62,y1,5+2.7)
canonical=one(raw.common(b(30,237-half,-1,45,237+half,11)).cut([slot(237-half-.05,237-half+slot_depth),slot(237+half-slot_depth,237+half+.05)]))
canonical=one(canonical.common(canonical.mirror(V(0,237,0),V(0,1,0))))
assert abs(canonical.BoundBox.YLength-8.0)<1e-6
ax_sym=canonical.cut(canonical.mirror(V(0,237,0),V(0,1,0))).Volume
assert ax_sym<1e-4,ax_sym
print('rotor_y_symmetry',ax_sym,flush=True)
cam=m(canonical,y=3.75,z=87)
# Restore the hidden bottom of the two lower blind bores. Keep access mouths inboard.
def cylinder(x,y,z,R,L,dy=1):return Part.makeCylinder(R,L,V(x,y,z),V(0,dy,0))
pl=cylinder(xc,240.99,5,4.31,2.40)
rl=cylinder(xc,241.0,5,4.28,12,-1)
front=one(r[2].fuse([front_mirror(pl),mir(front_mirror(pl))]).cut([front_mirror(rl),mir(front_mirror(rl))]))
fill=b(25.3,238.8,89.1,28.43,245.0,100.0)
rear=one(r[3].fuse([pl,mir(pl),fill,mir(fill)]).cut([rl,mir(rl)]))
trim=[b(24.9,244.45,89.1,25.3,245.1,95),b(25.29,245,89.1,28.43,245.1,95)]
rear=one(rear.cut(trim+[mir(s) for s in trim]))
pad=prism(25.3,18.7,[(239.05,82.4),(235.55,85.9),(235.55,100),(240,100),(240,82.4)])
rear=one(rear.fuse([pad,mir(pad)]))
seat=Part.makeCylinder(4.28,8.55,V(xc,236.55,zc),V(0,1,0))
entry=cyl(25.24,yc,2.40,8.57)
rear=one(rear.cut([p for k in (seat,entry) for p in (k,mir(k))]))
# A matching stepped return wall keeps the two relieved corners enclosed, with
# 0.80 mm nominated face clearance and an approximately 0.96 mm replacement wall.
core=prism(24.5,20.3,[(240,80.65),(234.75,85.9),(234.75,97),(240.5,97),(240.5,80.65)])
grow=prism(24.45,21.31,[(240,79.292355),(233.79,85.502355),(233.79,97),(240.5,97),(240.5,79.292355)])
patch=grow.cut(core).common(b(25.60,230,76,45.77,238,96))
old=r[14]
basket=one(old.cut([core,mir(core)]).fuse([patch,mir(patch)]))
print('drawer_material',old.Volume,basket.Volume,'patch',patch.Volume,basket.BoundBox,flush=True)
print('static',[(n,round(c(a,b),7)) for n,a,b in [('side/rod',side,rod),('side/rear',side,rear),('rear/rod',rear,rod),('rear/cam',rear,cam),('rod/cam',rod,cam),('drawer/rear',basket,rear)]],flush=True)
def sample(vals,fn):
 return [[t,*[round(x,7) for x in fn(t)]] for t in vals]
stations={
 'rear_upper':(cam,rod,rear,yc,92,1),
 'rear_lower':(canonical,r[8],rear,237,5,-1),
 'front_lower':(m(canonical,y=-224),r[6],front,13,5,1)
}
def right(s,y):
 t=s.copy();t.rotate(V(97.65,y,0),V(0,0,1),180);return t
results={}
forces=[]
for name,(wheel,stud,host,y,z,direction) in stations.items():
 def rotate(a):return spin(wheel,xc,y,z,a)
 opened=rotate(-80); locked=rotate(10)
 turn=sample(list(range(-90,11,5)),lambda a:(c(stud,rotate(a)),c(host,rotate(a))))
 pull=sample([0,-.025,-.05,-.1,-.2,-.3,-.6,-1,-2,-3,-4,-5,-6,-8,-10,-13],lambda x:(c(m(stud,x=x),opened),c(m(stud,x=x),host),c(m(stud,x=x),locked)))
 insert=sample([0,.2,.5,1,2,3,4,5,6,8,10,12,15],lambda t:(c(m(opened,y=direction*t),host),c(m(opened,y=direction*t),stud)))
 print(name,'turn',turn,'pull',pull,'insert',insert,flush=True)
 assert max(max(row[1:]) for row in turn)<.001 and max(row[1] for row in insert)<.001,name
 assert max(max(row[1:3]) for row in pull)<.001 and max(row[3] for row in pull)>.02,name
 other=right(wheel,y)
 rhs={'rear_upper':m(r[9],y=3.75,z=87),'rear_lower':r[9],'front_lower':r[7]}[name]
 def rrot(a):return spin(other,195.3-xc,y,z,-a)
 rcheck=sample(list(range(-90,11,10)),lambda a:(c(rhs,rrot(a)),c(host,rrot(a))))
 assert max(max(t[1:]) for t in rcheck)<.001 and c(m(rhs,x=.6),rrot(10))>.02,(name,rcheck)
 print(name,'right_checked',round(other.Volume,6),round(wheel.Volume,6),flush=True)
 results[name]=dict(turn=turn,pull=pull,insert=insert,assembly_order='cam first, rod next at -80 degrees')
base=r[:15]
full=base[:2]+[front,rear]+base[4:10]+[m(canonical,y=-224),right(m(canonical,y=-224),13),canonical,right(canonical,237),basket,rod,m(r[9],y=3.75,z=87),cam,right(cam,yc)]
# Test printed-cam lock engagement against the original with the same load probe.
rawl=spin(raw,xc,237,5,10); newl=spin(canonical,xc,237,5,10)
for delta in [.1,.2,.3,.6,1,2]:
 f=m(r[8],x=-delta)
 forces.append([delta,c(f,rawl),c(f,newl)])
assert all(abs(x-y)<.001 for _,x,y in forces),forces
# Compare unchanged mid-width capture geometry with the original by symmetric difference.
mid=b(30,234.55,-1,45,239.45,11)
old_core=raw.common(mid);new_core=canonical.common(mid)
core_loss=old_core.cut(new_core).Volume
assert core_loss<.12 and new_core.cut(old_core).Volume<.001,core_loss
def section(s,x):
 q=[V(x,228,-1),V(x,247,-1),V(x,247,11),V(x,228,11)]
 return s.common(Part.Face(Part.makePolygon(q+[q[0]]))).Area
area=[[x,section(raw,x),section(canonical,x)] for x in [34,35,36,37,38,39,40]]
print('load_sections',area,'core_diff',core_loss,flush=True)
print('load_witness',forces,flush=True)
assert max(c(m(rod,y=t),side) for t in [0,.2,.5,1,2,3,4,5,6,8,10,12])<.001
static=max(c(a,b) for i,a in enumerate(full) for b in full[i+1:])
print('max-static',static,flush=True)
travel=[0,-.1,-.3,-.6,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-12,-16,-22,-30,-45,-60,-85,-100,-110.5]
drawer=[]
paddle=[]
for d in travel:
 tray=m(basket,y=d)
 val=[(i,c(tray,p)) for i,p in enumerate(full) if p is not basket]
 drawer.append([d,round(max(v for i,v in val if i not in (4,5)),7)])
 for i,v in val:
  if i in (4,5) and v>.001:paddle.append([d,i,round(v,7)])
  if v>.001:print('contact',d,i,v,flush=True)
print('drawer',drawer,'paddle_contact',paddle,flush=True)
assert max(row[1] for row in drawer)<.001
assert all(t[0]==-110.5 for t in paddle),paddle
assert static<.001
assert abs(rear.optimalBoundingBox(False,False).YMax-245)<1e-5
assert abs(basket.optimalBoundingBox(False,False).YMax-old.optimalBoundingBox(False,False).YMax)<1e-5
assert basket.common(b(10,0,0,185,245,75)).cut(old).Volume<.001
assert old.common(b(10,0,0,185,245,75)).cut(basket).Volume<.001
def save(s,name,count):
 f=out/name;s.exportStep(str(f));ensure_mm(f,s)
 chk=Part.read(str(f));assert chk.isValid() and len(chk.Solids)==count
save(Part.makeCompound(full),'All_Eight_mm_Cams_Assembly.step',19)
qa=Part.read(str(out/'All_Eight_mm_Cams_Assembly.step'))
assert abs(qa.BoundBox.YLength-240)<1e-5 and qa.BoundBox.ZMax<102.701
for idx,x,y,z in [(10,37.2,13,5),(11,158.1,13,5),(12,37.2,237,5),(13,158.1,237,5),(17,37.2,240.75,92),(18,158.1,240.75,92)]:
 p=qa.Solids[idx].BoundBox
 assert abs(p.XMin-(x-4.1))<.01 and abs(p.YMin-(y-4))<.01 and abs(p.YMax-(y+4))<.01 and abs(p.ZMin-(z-4.1))<.01,(idx,p)
def cut_piece(s,x,y,z,u,v,w):return one(s.common(b(x,y,z,u,v,w)))
coupon=[]
for name in ('rear_upper','rear_lower','front_lower'):
 wheel,stud,host,y,z,direction=stations[name]
 lo_y,hi_y,lo_z,hi_z={
  'rear_upper':(228,245.1,80,100.1),
  'rear_lower':(228,245.1,-.1,9.8),
  'front_lower':(4.9,21.1,-.1,9.8)
 }[name]
 split=25.3 if name=='rear_upper' else 28.95
 coupon.append(Part.makeCompound([cut_piece(side,15,lo_y,lo_z,split,hi_y,hi_z),cut_piece(host,split if name=='front_lower' else 25.28,lo_y,lo_z,45,hi_y,hi_z),stud,wheel]))
 save(coupon[-1],f'8mm_{name}_Coupon.step',4)
metrics=dict(cad_sample_count=len(drawer),travel_mm=110.5,paddle_contacts_at_travel_limit_mm3=paddle,nominal_clearance_mm=.8,local_thickness_mm=outer-235.55,cam_diameter_mm=8.2,cam_thickness_mm=8.,rear_wall_nominal_mm=6.2,front_floor_mm=1.0,recess_mm=.25,slot_depth_mm=slot_depth,rod_axis_shift_mm=3.75,outward_mm=0.,overall_depth_mm=outer-5,drawer_corner_depth_loss_mm=3.25,drawer_material_delta_mm3=(basket.Volume-old.Volume),cabinet_nominal_depth_mm=250,volume_delta_mm3=rear.Volume-r[3].Volume,checked_lock_angle_deg=10,drawer_samples=drawer,joint_checks=results,core_pull_comparison_mm3=forces,core_removed_mm3=core_loss,section_screen_mm2=area,mid_core_span_mm=4.9,cam_solid_volume_original_mm3=raw.Volume,cam_solid_volume_candidate_mm3=canonical.Volume,max_static_overlap_mm3=static)
(out/'fit.json').write_text(json.dumps(metrics,indent=2)+'\n')
print('FIT',metrics,flush=True)
