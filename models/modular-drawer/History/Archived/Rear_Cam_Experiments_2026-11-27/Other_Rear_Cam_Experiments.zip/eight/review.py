import sys,json,base64,hashlib
from pathlib import Path
from report_geometry import Part,V,bbox,views,meshes,size
here=Path(__file__).parent; out=here/'final'; root=Path(sys.argv[1])
runtime=(root/'mz-viewer.runtime.js').read_text().replace('后板背插键 · 关合总成','六处 8 mm 偏心轮 · 小样对照')
base=(root/'rear-key-template.html').read_text()
intro=base[:base.index('<header>')].replace('<title>模块化抽屉 · 后板插键与关合评审</title>','<title>六处 8 mm 偏心轮 · 小样对照</title>')
viewer=base[base.index('<section id="review3d"'):base.index('<section id="joints"')]
viewer=viewer.replace('关闭总成和部件切换','完整关合总成与局部小样').replace('亮蓝绿：侧板　蓝：前梁　深蓝：后板　橙：插键、锁件与拨片','亮蓝绿：侧板　蓝：前梁　深蓝：后板　橙：偏心轮、拉杆与拨片')
full=out/'All_Eight_mm_Cams_Assembly.step'; coupon=out/'8mm_rear_upper_Coupon.step'
q=Part.read(str(full)); p=Part.read(str(coupon))
assert len(q.Solids)==19 and len(p.Solids)==4 and q.isValid() and p.isValid()
def part(s,name,d=.065):
 b=bbox(s);return dict(name=name,extent=size(b),nSolids=len(s.Solids),**meshes(s,b,d))
parts={'assembly':part(q,'完整关合总成',.12),'corner':part(p,'左后上角锁件小样'),'basket':part(q.Solids[14],'抽屉 · 后角避让',.12)}
for m in parts['basket']['meshes']:m['kind']='drawer'
for m,k in zip(parts['corner']['meshes'],['side','rear','hardware','hardware']):m['kind']=k
panels=[dict(id='corner',mesh='corner',title='后板上锁小样'),dict(id='basket',mesh='basket',title='抽屉 · 后角避让')]
other=[('rear_lower','后板下锁小样'),('front_lower','前梁锁小样')]
for k,title in other:
 f=out/f'8mm_{k}_Coupon.step'
 s=Part.read(str(f));assert s.isValid() and len(s.Solids)==4
 parts[k]=part(s,title)
 for packet,c in zip(parts[k]['meshes'],['side','rear' if k=='rear_lower' else 'front','hardware','hardware']):packet['kind']=c
 panels.append(dict(id=k,mesh=k,title=title))
draw=[]
items=[('side','① 原侧板裁片','沿用原侧板狭长槽，不打新孔。'),('rear','② 后板裁片','从外侧一孔装轮、拧轮；侧孔只供拉杆，不是第二个操作孔。'),('rod','③ 原规格直拉杆','使用原规格直拉杆，不再需要偏置过渡；固定端沿用侧板槽。'),('cam','④ 通用 8 mm 偏心轮','外径 Ø8.2 mm，两端一字槽。六处用同一几何件，安装方向不同。')]
items.append(('basket','⑤ 抽屉左后角 · 局部投影','为看清避让，图中只投影后角裁片；3D 下拉菜单可看完整抽屉。'))
detail=q.Solids[14].common(Part.makeBox(31.25,12.05,21.4,V(25.35,226,74.65)))
assert detail.isValid() and len(detail.Solids)
for (k,title,note),s in zip(items,[*p.Solids,detail]):
 if k!='basket':
  parts[k]=part(s,title)
  if k in ('side','rear'):parts[k]['meshes'][0]['kind']=k
  panels.append(dict(id=k,mesh=k,title=title))
 fs=[]
 for v in views(s,['rear_end','top','side'],include_tangent=True):
  w,h=v['extent'];x,y=(38-w)/2,(28-h)/2
  def xy(a,b):return (x+a,y+h-b)
  def pts(e):return ' '.join(f'{sx:.4f},{sy:.4f}' for a,b in e for sx,sy in [xy(a,b)])
  ls=''.join(f'<polyline fill="none" stroke="{c}" stroke-width=".16" {dash} points="{pts(e)}"/>' for layer,c,dash in zip(v['layers'],['#243b4b','#91a7ab'],['','stroke-dasharray=".65 .55"']) for e in layer)
  for a,b,r in v['visible_full_circles']:
   cx,cy=xy(a,b);ls+=f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke="#243b4b" stroke-width=".16" fill="none"/>'
  if k=='rear' and v['key']=='rear_end':
   cx,cy=xy(v['brep_bounds'][1]-37.2,92-v['origin'][1]);ls+=f'<path d="M {cx:.3f} {cy:.3f} L {cx+6:.3f} {cy-5:.3f} H 35" fill="none" stroke="#bd651a" stroke-width=".16"/><text x="25" y="{cy-5.65:.3f}" fill="#a55014" font-size="1.24">Ø8.56 轮孔</text>'
  if k=='rear' and v['key']=='side':
   yy=y+h+1.3; xa=x+235.55-v['origin'][0];xb=x+245-v['origin'][0]
   ls+=f'<path d="M {xa:.3f} {yy-1:.3f} v 1.3 M {xb:.3f} {yy-1:.3f} v 1.3 M {xa:.3f} {yy:.3f} H {xb:.3f}" fill="none" stroke="#bd651a" stroke-width=".16"/><text x="{(xa+xb)/2:.3f}" y="{yy+1.45:.3f}" fill="#a55014" font-size="1.2" text-anchor="middle">局部厚 9.45</text>'
  fs.append(f'<figure class="view"><figcaption>{v["title"]}<small>{v["axes"]} ｜ {w:g} × {h:g} mm</small></figcaption><svg viewBox="0 0 38 31" aria-label="{v["title"]}">{ls}</svg></figure>')
 draw.append(f'<div class="sheet"><h3>{title}</h3><p>{note}</p><div class="ortho">{"".join(fs)}</div></div>')
fit=json.loads((out/'fit.json').read_text())
lead='''<main class="wrap"><div class="hero"><p class="kicker">独立试验 · 不替换项目现版</p><h1>六处试用同一款 8 mm 偏心轮</h1><p class="lead">前梁两处、后板下方两处、后板上方两处。8 mm 是验证目标，不是正式定版。</p></div>'''
depth=fit['overall_depth_mm']
area=fit['section_screen_mm2']; lows=min(a[2]/a[1] for a in area if a[1]>0)
paddle='排除原限位拨片后，固定框架全程没有检出干涉。' if fit.get('paddle_contacts_at_travel_limit_mm3') else '所有采样位置均未检出干涉。'
if fit.get('paddle_contacts_at_travel_limit_mm3'):paddle+=' 补查中，105 mm 未碰限位拨片，108 mm 时抽屉后角已碰到；未验证解锁后可继续拉出。'
rows=''.join(f'<li>距左侧基准 X = {x:g} mm：{a:.2f} → {b:.2f} mm²</li>' for x,a,b in area)
metrics=f'''<section><h2>空间与装配</h2><div class="sheet"><p><strong>6 颗轮统一 Ø8.2 × 8 mm，背面齐平，整组深 240 mm。</strong>后上锁座从 12.65 mm 降到 9.45 mm，抽屉两个后上角最大让位从 6.45 mm 减到 3.25 mm。抽屉底板、滑轨、总体长宽高不变。</p><p>前梁、后板下锁座只补浅盲孔的深处，外轮廓不动。下两组仍从原来的内侧开口操作。后上轮从背面装入并操作，低于平面 0.25 mm。</p><p><strong>装配顺序：先把轮放进座里，再在解锁角插拉杆。</strong>带着拉杆硬塞轮会干涉。三类锁位验证了空座入轮、解锁角进退杆、转轮和锁端防脱。抽屉从关到底至拉出 110.5 mm 采样 23 个位置。{paddle}</p></div></section><section><h2>强度取舍：只能试打，不建议直接全换</h2><div class="sheet"><p>对照原厚轮，拉杆头的防拔接触位置与阻挡样点一致。这说明工作轮廓还在，不代表夹紧力或耐用性相同。沿拉杆方向抽查的截面，8 mm 版只剩原轮的最低约 {lows:.0%}；按扳手槽深与内部开口的几何包络估算，槽底局部可只余约 0.72 mm。更值得担心的是拧槽崩边、疲劳后松动，不是几何上是否能卡住。</p><details><summary>查看 CAD 截面面积，不是应力结果</summary><ul>{rows}</ul></details><p><strong>建议：</strong>试打时用相同材料和摆放，对照 11.2 mm 原轮，先检查拧紧、反复解锁、侧向摇晃。只要崩槽或明显更松，就不要替换。后续如仍要减薄，优先试 9.5 mm：同一种裁薄与开槽方法的截面筛查约为原轮的 65%，槽底几何余料约 1.47 mm；尚未验证该厚度的锁位。正式版不改。没有做材料强度仿真、实打或切片。</p></div></section>'''
def link(f,label,mime='application/octet-stream'):
 data=base64.b64encode(f.read_bytes()).decode()
 return f'<a href="data:{mime};base64,{data}" download="{f.name}">{label}</a>'
links=' · '.join([link(full,'19 实体总成 STEP'),link(coupon,'后板上锁 4 件 STEP'),*[link(out/f'8mm_{k}_Coupon.step',f'{title} 4 件 STEP') for k,title in other],link(out/'fit.json','CAD 样点数据','application/json')])
body=metrics+viewer+f'<section><h2>按实际 STEP 投影的三视图</h2><p>统一比例，单位 mm。实线：可见；虚线：隐藏；橙色：关键尺寸或特征。</p>{"".join(draw)}</section><section><h2>下载</h2>{links}<p class="sheet-note">总成 STEP SHA-256: {hashlib.sha256(full.read_bytes()).hexdigest()}</p></section></main>'
data=json.dumps(dict(parts=parts,panels=panels),ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
f=out/'Drawer_All_8mm_Cams_Review.html'
f.write_text(intro+lead+body+f'<script type="application/json" id="cad-data">{data}</script><script>{runtime}</script></body></html>')
print(f,f.stat().st_size)
