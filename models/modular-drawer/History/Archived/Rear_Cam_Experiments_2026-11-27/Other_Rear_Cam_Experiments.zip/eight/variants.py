import FreeCAD as A,Part,sys,json
from pathlib import Path
from step_units import ensure_mm
V=A.Vector
r=Part.read(sys.argv[1]).Solids
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def b(x,y,z,u,v,w):return Part.makeBox(u-x,v-y,w-z,V(x,y,z))
def m(s,x=0,y=0,z=0):return s.translated(V(x,y,z))
def c(a,b):
 if not a.BoundBox.intersect(b.BoundBox):return 0.
 return a.common(b).Volume
def one(s):
 s=s.removeSplitter()
 assert s.isValid() and len(s.Solids)==1,(s.isValid(),len(s.Solids))
 return s.Solids[0]
def mir(s):return s.mirror(V(97.65,0,0),V(1,0,0))
def ring(x,y,rad): return Part.Wire([Part.makeCircle(rad,V(x,y,92),V(1,0,0))])
def loft(x,y,u,v,rad):return Part.makeLoft([ring(x,y,rad),ring(u,v,rad)],True,True)
def cyl(x,y,rad,length):return Part.makeCylinder(rad,length,V(x,y,92),V(1,0,0))
side=r[0]; yc=240.75; xc=37.2; zc=92.; outer=245.0
def spin(s,x,y,z,a):
 t=s.copy();t.rotate(V(x,y,z),V(0,1,0),a);return t
def rot(s,a):return spin(s,xc,yc,zc,a)
def prism(x,width,yz):
 pts=[V(x,y,z) for y,z in yz]
 return Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(width,0,0))
def front_mirror(s):return s.mirror(V(0,125,0),V(0,1,0))
rod=m(r[8],y=3.75,z=87)
raw=r[12]
half=4.0
slot_depth=.85
def slot(y0,y1):return b(xc-.62,y0,5-2.7,xc+.62,y1,5+2.7)
canonical=one(raw.common(b(30,237-half,-1,45,237+half,11)).cut([slot(237-half-.05,237-half+slot_depth),slot(237+half-slot_depth,237+half+.05)]))
canonical=one(canonical.common(canonical.mirror(V(0,237,0),V(0,1,0))))
assert abs(canonical.BoundBox.YLength-8.0)<1e-6
ax_sym=canonical.cut(canonical.mirror(V(0,237,0),V(0,1,0))).Volume
assert ax_sym<1e-4,ax_sym
print('rotor_y_symmetry',ax_sym,flush=True)
cam=m(canonical,y=3.75,z=87)
def section(s,x):
 q=[V(x,228,-1),V(x,247,-1),V(x,247,11),V(x,228,11)]
 return s.common(Part.Face(Part.makePolygon(q+[q[0]]))).Area
area=[[x,section(raw,x),section(canonical,x)] for x in [34,35,36,37,38,39,40]]
print('load_sections',area,flush=True)
for thick in (8.5,9,9.5,10):
 h=thick/2
 t=one(raw.common(b(30,237-h,-1,45,237+h,11)).cut([slot(237-h-.05,237-h+slot_depth),slot(237+h-slot_depth,237+h+.05)]))
 mm=[section(t,x)/a for x,a,_ in area]
 print(thick,round(min(mm),4),round(h-2.43-slot_depth,2),flush=True)
